
Get twitter oAth credentials at https://apps.twitter.com/.

